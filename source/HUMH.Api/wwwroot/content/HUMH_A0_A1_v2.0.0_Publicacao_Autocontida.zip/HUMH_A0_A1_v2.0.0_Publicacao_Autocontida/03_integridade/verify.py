#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, sys

root = Path(__file__).resolve().parents[1]
sumfile = root / "03_integridade" / "SHA256SUMS.txt"
lockfile = root / "02_dependencias" / "DEPENDENCIES.lock.json"

errors = []

def sha256(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

for line in sumfile.read_text(encoding="utf-8").splitlines():
    if not line.strip():
        continue
    expected, rel = line.split("  ", 1)
    p = root / rel
    if not p.exists():
        errors.append(f"MISSING: {rel}")
        continue
    actual = sha256(p)
    if actual != expected:
        errors.append(
            f"HASH MISMATCH: {rel}\n"
            f"  expected={expected}\n"
            f"  actual  ={actual}"
        )

lock = json.loads(lockfile.read_text(encoding="utf-8"))

for dep in lock["active_canonical_dependencies"]:
    if dep.get("bundled") is not True:
        errors.append(f"ACTIVE DEPENDENCY NOT BUNDLED: {dep.get('artifact_id')}")
        continue
    p = root / dep["path"]
    if not p.exists():
        errors.append(f"ACTIVE DEPENDENCY MISSING: {dep.get('artifact_id')}")
        continue
    actual = sha256(p)
    if actual != dep["sha256"]:
        errors.append(
            f"CANONICAL HASH MISMATCH: {dep.get('artifact_id')}\n"
            f"  expected={dep['sha256']}\n"
            f"  actual  ={actual}"
        )

if errors:
    print("FAIL")
    for e in errors:
        print(e)
    sys.exit(1)

print("PASS")
print("All materialized files match SHA256SUMS.")
print("Both active canonical dependencies are bundled and match their frozen SHA-256 locks.")
