# HUMH — A0/A1 · Especificação Experimental v2.0.0
## Reset de rastreabilidade à definição canônica

**Identidade:** `HUMH_A0_A1_SPEC_2.0.0_TRACEABILITY_RESET`  
**Referente normativo primário para A0/A1:** `HUMH_ATTENTION_DEFINITION_1.0.0`  
**Definition SHA-256:** `3f89058c0931515abe94f56393733cdebed8f49a35003ae1b17949686540bb7a`  
**Theory SHA-256:** `3ce6c097a11c7c33cc94439e44d2ec2821b60affbfedec8401cc9572d58bf23b`  
**Nucleus SHA-256:** `baeba8eae26a939b849b1dc0763c69062e2fa61728ddbec31109e72985c8015b`  
**Program SHA-256:** `a9bfd724b7af7849711570798eb8134282fa93fe39093fbd7f4b637041f5a226`  
**KREF0 SHA-256:** `234c752534589f84d53836cdc18d3964ba30c17783292f977fbf6fcfdeeef6f7`

**Status:** `PRE_CODE_TRACEABILITY_FREEZE`  
**Run científico:** `SCIENTIFIC_RUN_NOT_AUTHORIZED`  
**Motivo:** além dos valores ainda não congelados, a microdinâmica do observador para A1a permanece `UNRESOLVED_CANONICAL_MAPPING`. `ANBC0` deve demonstrar prospectivamente que a separabilidade não é consequência algébrica de serving/thinning antes de qualquer run científico.

---

# 1. Regra-mãe de v2.0.0

> **Nenhuma variável, Gate, hipótese, contraste, margem ou condição de decisão entra no experimento sem apontar primeiro qual afirmação da definição canônica ela operacionaliza.**

Esta regra é executável:

1. todo item científico ou de integridade deve existir no `HUMH_A0_A1_Traceabilidade_v2.0.0.json`;
2. todo item deve informar `canonical_refs`;
3. cada `canonical_ref` deve conter, no mínimo, `artifact_id`, `sha256`, `section` e `clause_or_statement`;
4. `canonical_refs=[]` invalida o item;
5. o SHA declarado em cada referência deve coincidir com o artefato canônico registrado no manifesto;
6. itens apenas de implementação devem ser marcados `IMPLEMENTATION_ONLY` e não podem entrar em nenhuma conclusão científica;
7. nenhum novo Gate científico pode ser acrescentado durante a implementação;
8. verificações auxiliares podem existir apenas como **subchecks** de um Gate canônico já autorizado;
9. se uma necessidade nova não puder ser mapeada a um artefato canônico qualificado, a implementação para e a spec precisa ser revista antes de nova coleta.

---


## 1.1. Autoridade normativa desta versão

A v2.0.0 consolidada possui exatamente dois artefatos normativos:

```text
HUMH_A0_A1_Especificacao_Experimental_v2.0.0.md
HUMH_A0_A1_Traceabilidade_v2.0.0.json
```

Arquivos auxiliares produzidos durante a elaboração da v2.0.0 não possuem autoridade
normativa e não são necessários para interpretar, implementar ou auditar o desenho.

Toda regra válida de `p_alvo`, instrumento de atenção, `AETA0`, `ANBC0`, `M_alt`,
lógica de resultados e sequência científica está incorporada nestes dois artefatos.


# 2. Regra de não herança científica da série v1.0.x

A série experimental v1.0.x é classificada, para a v2.0.0, como:

`PREVIOUS_OUTCOMES_EXPOSED_DIAGNOSTIC_ONLY`

Ela pode ser usada para reconhecer bugs de software, riscos de implementação e necessidades de auditoria já conhecidas.

Ela **não pode** ser usada para escolher na v2.0.0:

- braços HIGH/MID/LOW;
- budgets correspondentes;
- `W`;
- `L_A`, exceto via novo `ABENCH0` cego técnico;
- `delta_drive`;
- número mínimo de passos;
- informação mínima `sum(x^2)`;
- fronteiras dos estratos de estado;
- margem de equivalência/refutação;
- subconjunto de contrastes;
- tamanho amostral;
- regra de multiplicidade;
- competência mínima de `ACOMP0`.

Nenhum resultado v1.0.x é reclassificado por esta spec.

---

# 3. Sequência científica autorizada pela definição

A v2.0.0 preserva literalmente a sequência conceitual:

```text
A0  = ATTENTION MEASUREMENT CONTRACT
A1a = ATTENTION MULTIPLICATIVE SEPARABILITY
A1b = ATTENTION DISTRIBUTION EFFECT
A2  = ATTENTION–MACRO TRANSPORT — NOT AUTHORIZED / NOT TESTED
```

Não há A2 nesta especificação.

---

# 4. Vocabulário teórico fechado

## 4.1 Atenção individual

\[
\boxed{
A_i(W)=\frac{U_i(W)}{D_i(W)}
}
\]

`A_i` é a variável teórica de atenção.

### D_i(W)

\[
D_i(W)=
\#\{\text{requisições observacionais elegíveis geradas exogenamente para }O_i\text{ em }W\}.
\]

### U_i(W)

Número de requisições de `D_i` cuja cadeia

\[
observação\rightarrow processamento\rightarrow atualização
\]

termina dentro do deadline lógico comum.

### W

Janela em ciclos lógicos.

### L_A

Uma requisição criada em `t` entra em `U_i` somente se:

\[
t_{complete}\le t+L_A.
\]

`L_A` é comum aos braços e independente de atenção, `EH`, inércia e outcome.

## 4.2 Atenção coletiva

\[
\boxed{
\bar A=\frac1N\sum_i A_i
}
\]

\[
\boxed{
D_A=\frac1N\sum_i|A_i-\bar A|
}
\]

Estas são as únicas agregações de atenção autorizadas pela definição para A1.

## 4.3 Variáveis que NÃO existem nesta teoria

Ficam proibidas como variáveis científicas da v2.0.0:

```text
A_global
A_by_stratum
A_stratum
AEXP
exposure_stability_across_EH
qualquer outra redefinição de A_i por estrato de EH
```

É permitido calcular valores temporários para depuração do software, desde que sejam `IMPLEMENTATION_ONLY`, não persistam no dataset científico e não participem de Gates ou decisões.

---

# 5. Instrumento causal de atenção

A variável de implementação causal é:

\[
P_i^{obs}
\]

com cadeia:

\[
\boxed{
P_i^{obs}\rightarrow A_i.
}
\]

`P_i^{obs}`, budget, quantum ou prioridade local são **instrumentos de manipulação**, não são atenção.

O scheduler pode decidir oportunidade de execução e cumprimento de `L_A`, mas não pode modificar demanda exógena, dinâmica estrutural ou regra interna do observador em função do braço.

---


# 5.1. Instrumento computacional de atenção — congelado

A variável teórica permanece exclusivamente:

\[
\boxed{A_i(W)=U_i(W)/D_i(W)}.
\]

No substrato WebWorker, o instrumento causal `P_i^{obs}` é operacionalizado como:

```text
observer_work_budget
```

um orçamento lógico determinístico de trabalho observacional disponível por ciclo.

Portanto:

```text
observer_work_budget != A_i
observer_work_budget -> A_i
```

O budget é instrumento; `A_i` é a atenção efetivamente obtida e medida.

## 5.1.1. Pareamento entre braços

Para o mesmo observador em braços pareados permanecem idênticos:

```text
observer_id
estado inicial
parâmetros basais do observador
sequência de demandas
demand_id
payload/conteúdo
required_work
regra de processamento
regra basal de atualização
L_A
seeds exógenas
```

Varia somente:

```text
observer_work_budget
```

Assim, a mesma informação para o mesmo observador pode completar sua cadeia em menos
ciclos lógicos quando dispõe de maior recurso observacional.

## 5.1.2. Tempo científico

A unidade científica é o ciclo lógico:

```text
logical_cycle = SCIENTIFIC_TIME
wall_clock_ms = DIAGNOSTIC_ONLY
cpu_time_ms = DIAGNOSTIC_ONLY
```

O resultado científico não pode depender de turbo, frequência física da CPU,
escalonamento do sistema operacional ou duração real do WebWorker.

## 5.1.3. Demanda e trabalho requerido

Cada demanda é definida antes de consultar o braço:

```text
demand_id
observer_id
arrival_cycle
payload_id
payload
required_work
remaining_work
deadline_cycle = arrival_cycle + L_A
```

`required_work` é `arm-blind` e idêntico entre braços pareados.

Uma unidade:

```text
WORK_QUANTUM = 1
```

é uma unidade abstrata de progresso lógico. Não equivale a 1 ms, 1 instrução física,
1% de CPU ou um timeslice real.

## 5.1.4. Fila observacional

Cada observador possui fila própria:

```text
FIFO_DETERMINISTIC
```

A prioridade não pode depender de:

```text
EH
p_i
sucesso/falha
outcome
braço
budget
estado futuro
```

## 5.1.5. Algoritmo lógico de serviço

No início de cada ciclo:

```text
budget_remaining = observer_work_budget

while budget_remaining > 0 and queue not empty:
    job = queue.front

    if current_cycle > job.deadline_cycle:
        mark DEMAND_NOT_SERVED_IN_TIME
        remove job
        continue

    q = min(budget_remaining, job.remaining_work)

    execute exactly q logical work quanta
    job.remaining_work -= q
    budget_remaining -= q

    if job.remaining_work == 0:
        execute the same basal observer update
        record completion_cycle

        if completion_cycle <= deadline_cycle:
            count exactly once in U_i

        remove job
```

No primeiro A1, uma demanda não concluída até o primeiro ciclo posterior ao deadline:

```text
permanece em D_i
não entra em U_i
não produz atualização tardia
é removida da fila
```

Esta é uma operacionalização experimental, não uma afirmação ontológica sobre atenção humana.

## 5.1.6. Significado de “processar mais rápido”

Neste instrumento, “mais rápido” significa completar a mesma cadeia em menos ciclos
lógicos devido a maior recurso observacional disponível por ciclo.

Se uma demanda requer `C` quanta e não existe fila anterior:

\[
L_{proc}\approx \lceil C/B\rceil.
\]

Logo:

\[
B_{HIGH}>B_{LOW}
\]

pode produzir:

\[
L_{HIGH}<L_{LOW}.
\]

Isso não redefine atenção como velocidade. A atenção continua sendo medida a posteriori
por:

\[
A_i=U_i/D_i.
\]

## 5.1.7. Não equivalências

Ficam proibidas:

```text
A_i := observer_work_budget
A_i := 1 / processing_latency
A_i := CPU_percent
A_i := thread_priority
A_i := wall_clock_speed
```

## 5.1.8. Manipulation check

Não basta:

```text
B_HIGH > B_LOW.
```

O instrumento só é aceito se `ABENCH0/AMAN0`, usando exclusivamente quantidades
instrumentais congeladas, confirmar contraste adequado em:

\[
A_{HIGH}>A_{LOW}.
\]

`eta_hat`, `EH`, consenso e outcomes A1a/A1b não podem participar da escolha dos budgets.

## 5.1.9. Separação de CANAL_ETA

O módulo `CANAL_ETA` não recebe:

```text
observer_work_budget
D_i
U_i
A_i
deadline_misses
remaining_work
queue_length
```

Somente após os dois canais terminarem é permitido comparar `eta_hat` com `A_i`.

## 5.1.10. Parâmetros numéricos pendentes

A versão run-ready ainda deve congelar prospectivamente:

```text
required_work_rule
required_work_range_or_constant
observer_work_budget_arms
L_A
W
number_of_arms
instrumental_contrast_criteria
saturation_avoidance_criteria
```

Status:

```text
ATTENTION_INSTRUMENT_SEMANTICS = FROZEN
ATTENTION_INSTRUMENT_ALGORITHM = FROZEN
ATTENTION_INSTRUMENT_NUMERICS = UNFROZEN_REQUIRED_BEFORE_RUN
```
# 6. Dois canais de mensuração — separação obrigatória

## CANAL_A

Entradas permitidas:

```text
D_i
U_i
```

Saída:

\[
A_i=U_i/D_i.
\]

## CANAL_ETA

Entradas permitidas:

```text
p_i(t)
p_alvo,i(t)
metadados estritamente necessários para elegibilidade de trajetória
```

Defina:

\[
x_{it}=p_{alvo,i}(t)-p_i(t)
\]

\[
y_{it}=p_i(t+1)-p_i(t)
\]

e, para cada observador/condição/estrato de estado prospectivamente definido:

\[
\boxed{
\widehat\eta=
\frac{\sum_{t\in\mathcal E}x_{it}y_{it}}
{\sum_{t\in\mathcal E}x_{it}^{2}}
}
\]

O CANAL_ETA é proibido de ler direta ou indiretamente:

```text
U_i
D_i
A_i
A_bar
D_A
attention_arm
attention_budget
served_fraction
deadline_misses
```

A razão `eta_hat/A_i` só é formada depois de os dois canais terminarem.

---


# 6.1. Contrato operacional de `p_alvo` — CONGELADO

A linhagem canônica permite fechar o significado de `p_alvo` sem criar uma nova variável.

Na teoria basal:

\[
\frac{dp}{dt}
=
\eta(p)\,[p_{\text{alvo}}(s)-p(t)],
\]

e `p_alvo(s)` é o **atrator basal ativo** determinado pelo estado do sistema. No regime estável em A, antes de saturação, `p_alvo=p_A`; no regime estável em B, antes de saturação, `p_alvo=p_B`.

A definição de atenção individualiza apenas o registro:

\[
x_{it}=p_{\text{alvo},i}(t)-p_i(t),
\]

exigindo que `p_alvo,i(t)` seja produzido pela dinâmica basal antes da atualização e sem usar contadores de atenção.

Portanto, A1 congela:

\[
\boxed{
p_{\text{alvo},i}(t)=p_{Z_e}
}
\]

onde:

```text
e   = episódio basal
Z_e ∈ {A,B} = atrator basal ativo do episódio
p_{Z_e} ∈ {p_A,p_B}
```

e o mesmo `p_{Z_e}` vale para todos os observadores e todos os ciclos pertencentes ao episódio `e`.

Status:

```text
P_TARGET_OPERATIONAL_STATUS = FROZEN_STATIONARY_ACTIVE_ATTRACTOR
```

## 6.1.1. Por que o episódio é estacionário

A1 testa atenção, não a mecânica de saturação/manutenção nem a troca de atratores.

A hipótese H-A1S exige comparação para o mesmo observador/estado basal. Portanto, a unidade primária de identificação de `eta_hat` é um trecho no qual o atrator basal ativo permanece fixo.

A1 utiliza apenas os trechos canônicos:

```text
REGIME_A_UNSATURATED: p_alvo = p_A
REGIME_B_UNSATURATED: p_alvo = p_B
```

A transição:

```text
A -> B por saturação
B -> A por saturação
```

não é outcome de A1 e não entra no estimando de A1a.

Isso não afirma que a saturação não exista. Apenas condiciona A1 a janelas basais estacionárias para não misturar atenção com a dinâmica de troca de atrator.

## 6.1.2. O que `p_alvo` NÃO é em A1

Ficam explicitamente excluídos:

```text
p_alvo != A_i
p_alvo != A_bar
p_alvo != D_A
p_alvo != U_i/D_i
p_alvo != budget
p_alvo != attention_arm
p_alvo != served_fraction
p_alvo != média dos vizinhos
p_alvo != maioria dos vizinhos
p_alvo != consenso observado no mesmo ciclo
p_alvo != reconstrução pós-hoc da trajetória
```

Um sinal observacional ou evidência local pode fazer parte do conteúdo da demanda basal, mas **não redefine `p_alvo`**: o alvo do estimador continua sendo o atrator basal ativo.

## 6.1.3. Ordem temporal obrigatória

Para cada episódio `e` e ciclo `t`:

```text
1. Z_e já está congelado antes do ciclo.
2. Registrar p_pre_i(t) = p_i(t).
3. Registrar p_alvo_i(t) = p_Ze.
4. Gerar/registrar a demanda observacional D_i(t) e seu conteúdo exógeno.
5. O scheduler decide apenas oportunidade/serviço/deadline.
6. Se a cadeia observacional for executada, chamar a rotina basal do observador.
7. Registrar p_i(t+1).
8. Somente depois formar:
      x_it = p_alvo_i(t) - p_i(t)
      y_it = p_i(t+1) - p_i(t)
```

A rotina do observador não recebe:

```text
A_i
A_bar
D_A
attention_arm
attention_budget
served_fraction
```

## 6.1.4. Pareamento e CRN

Para braços de atenção comparados dentro da mesma replicação:

```text
episode_id                 idêntico
Z_e                        idêntico
p_alvo                     idêntico
estado inicial pareado     idêntico
conteúdo de D_i            idêntico
RNG exógeno basal          idêntico por chave
topologia                  idêntica
microdinâmica basal        idêntica
```

A única intervenção autorizada é:

```text
P_i_obs -> A_i
```

Se o checksum da sequência `(episode_id, Z_e, p_alvo, D_i content)` divergir entre braços:

```text
AINT0 = FAIL
ASEP0 = INCONCLUSIVE_INTEGRITY
```

## 6.1.5. Identidade entre observadores

O índice `i` em `p_alvo,i(t)` existe para que cada linha de trajetória seja auto-contida.

No A1 inicial:

\[
\boxed{
p_{\text{alvo},1}(t)=\cdots=p_{\text{alvo},N}(t)=p_{Z_e}
}
\]

dentro do mesmo episódio.

A1 não introduz alvos idiossincráticos por observador.

## 6.1.6. Parâmetros numéricos ainda delegados à versão run-ready

O significado de `p_alvo` fica congelado aqui, mas ainda devem ser congelados prospectivamente, sem usar outcomes v1.0.x:

```text
p_A
p_B
número de episódios A/B
ordem/balanceamento dos episódios
comprimento de episódio
regra de inicialização de p_i
burn-in, se houver
regra exata que certifica ausência de troca de atrator dentro do episódio
```

Esses parâmetros são de desenho; não mudam a definição de `p_alvo`.

## 6.1.7. Referências canônicas

`p_alvo` possui referências qualificadas a:

1. `HUMH_ATTENTION_DEFINITION_1.0.0`, §§38–39:
   - CANAL_ETA usa `p_i(t), p_alvo,i(t)`;
   - o alvo deve ser registrado pela dinâmica basal antes da atualização;
   - o alvo não pode ser reconstruído dos contadores de atenção.

2. `teoria.md`, §4.3.5:
   - `dp/dt = eta(p)[p_alvo(s)-p(t)]`;
   - em A não saturado, `p_alvo=p_A`;
   - em B não saturado, `p_alvo=p_B`;
   - a troca de alvo pertence à dinâmica de saturação.

3. `HUMH_ATTENTION_DEFINITION_1.0.0`, §§45, 47–50:
   - scheduler decide apenas oportunidade de execução;
   - H-A1S compara a resposta de atenção para o mesmo estado basal;
   - `eta/A` é o objeto normalizado, não uma redefinição do alvo.

Com isso:

```text
P_TARGET_SEMANTIC_CONTRACT = FROZEN
P_TARGET_NUMERICS = UNFROZEN_REQUIRED_BEFORE_RUN
```

`p_alvo` deixa de ser bloqueio conceitual de v2.0.0. O run científico continua não autorizado pelos demais parâmetros ainda não congelados.

# 7. Regra executada pelo observador

É proibido inserir na rotina do observador:

```text
A_i
A_bar
D_A
attention_arm
attention_budget
served_fraction
qualquer transformação direta desses itens
```

Em particular, a equação teórica

\[
\eta_i(A,p)=
A_i\frac{\omega_i}{1+\iota_{obs,i}+\kappa EH(p)}
\]

**não pode** ser codificada como regra de atualização.

Ela é hipótese macroscópica/observacional a ser confrontada pelos dois canais independentes.

---


## 7.1. Status da microdinâmica científica de A1a

A v2.0.0 **não congela ainda uma rotina de atualização do observador**.

```text
A1A_OBSERVER_MICRODYNAMIC = UNRESOLVED_CANONICAL_OR_AUXILIARY_MAPPING
ANBC0 = NOT_READY_FOR_CLASSIFICATION
ASEP0_CONFIRMATORY = NOT_AUTHORIZED
```

A razão não é falta de código. É a exigência canônica dos §§52–54: uma rotina que não leia `A` ainda pode produzir `eta ∝ A` automaticamente se o scheduler funcionar como um thinning multiplicativo da dinâmica.

Nenhuma rotina da série v1.0.x pode ser herdada por conveniência. Ela deve primeiro possuir derivação canônica qualificada e passar `ANBC0`.

A especificação presente e o manifesto de rastreabilidade são as únicas fontes
normativas desta auditoria. Não existe contrato auxiliar com autoridade própria.


# 8. A0 — ATTENTION MEASUREMENT CONTRACT

A0 não é teste da teoria.

A0 congela e verifica o instrumento:

```text
D_i
U_i
W
L_A
A_i=U_i/D_i
contadores
deadline
regras de descarte
ABENCH0
p_alvo
eta_hat
elegibilidade de eta_hat
independência CANAL_A/CANAL_ETA
ausência de atenção na regra do observador
ANBC0
```

A0 bem-sucedido significa apenas:

`ATTENTION_MEASUREMENT_CONTRACT_VALID`

Não significa suporte à HUMH.

---

# 9. ABENCH0 — benchmark cego de instrumentação

Se `L_A=1` não for tecnicamente adequado, um novo benchmark cego selecionará `L_A`.

Antes de executar ABENCH0, devem ser congelados:

```text
L_grid
budgets exclusivamente instrumentais
faixa admissível de A para evitar saturação
contraste instrumental mínimo
regra determinística de desempate
```

ABENCH0 pode observar apenas:

```text
D_i
U_i
A_i
latência técnica
deadline_misses
queue/service timing
runtime metadata
hardwareConcurrency
```

É proibido observar ou exportar:

```text
eta_hat
p_i(t)
EH
consenso
dispersão de crença
qualquer outcome de A1a/A1b
```

Se nenhum `L_A` satisfizer a regra congelada:

```text
ABENCH0 = FAIL
SCIENTIFIC_RUN_NOT_AUTHORIZED
```

---

# 10. H-A1S — hipótese científica de A1a

Hipótese canônica:

\[
\boxed{
\eta_i(A,p)=A_i\,\eta_i^{(0)}(p)
}
\]

com

\[
\eta_i^{(0)}(p)=
\frac{\omega_i}
{1+\iota_{obs,i}+\kappa EH(p)}.
\]

Predição de razão, para o mesmo observador/estado basal:

\[
\boxed{
\frac{\eta_i(A_2,p)}
{\eta_i(A_1,p)}
=
\frac{A_{i,2}}
{A_{i,1}}
}
\]

Predição normalizada:

\[
\boxed{
\frac{\eta_i(A,p)}{A_i}
=
\eta_i^{(0)}(p).
}
\]

A1a não testa que HIGH executa mais updates que LOW. Isso é apenas manipulation check.

---


# 10.1. Estatuto teórico de H-A1S — teoria-base, extensão prospectiva e alternativas

A v2.0.0 separa explicitamente três níveis que não podem ser confundidos.

## 10.1.1. Teoria-base

A teoria-base fornece:

\[
\eta_i^{(0)}(p)
=
\frac{\omega_i}
{1+\iota_{obs,i}+\kappa EH(p)}
\]

Nesse nível:

```text
omega_i      = ritmo/propriedade basal do observador
iota_obs_i   = resistência basal do observador à atualização
kappa*EH(p)  = resistência associada ao estado de ordenação
```

A teoria-base não contém, por si só, o fator `A_i` multiplicando o numerador.

## 10.1.2. H-A1S é extensão prospectiva

A definição de atenção introduz prospectivamente:

\[
\boxed{
\eta_i(A,p)
=
A_i\,
\frac{\omega_i}
{1+\iota_{obs,i}+\kappa EH(p)}
}
\]

como hipótese mecanística falsificável.

Portanto:

```text
H-A1S != consequência já deduzida da teoria-base
H-A1S = extensão prospectiva a ser confrontada experimentalmente
```

A v2.0.0 não cria nem utiliza uma variável teórica `omega_eff`.
A expressão `A_i*omega_i` é apenas a forma algébrica postulada por H-A1S.

## 10.1.3. Pareamento do mesmo observador

No contraste A1a, o mesmo observador mantém invariantes seus parâmetros basais:

```text
omega_i
iota_obs_i
demais parâmetros estruturais do observador
```

A intervenção planejada atua no instrumento de atenção:

```text
P_i_obs -> A_i
```

A operacionalização principal não redefine `iota_obs_i` em função do braço.
Manipular simultaneamente `A_i` e `iota_obs_i` seria uma segunda intervenção.

## 10.1.4. Formas alternativas M_alt

A1a deve permanecer capaz de distinguir H-A1S de alternativas nas quais a atenção
não atua como fator multiplicativo separável.

Exemplos de `M_alt`:

### Resistência aditiva dependente de atenção

\[
\eta_i(A,p)
=
\frac{\omega_i}
{1+\iota_{obs,i}+h(A_i)+\kappa EH(p)}.
\]

### Interação atenção × resistência

\[
\eta_i(A,p)
=
\frac{A_i\omega_i}
{1+\iota_{obs,i}+\phi(A_i,\iota_{obs,i})+\kappa EH(p)}.
\]

### Outra forma não separável

\[
\eta_i(A,p)=F(A_i,p,\omega_i,\iota_{obs,i},EH).
\]

Essas formas:

```text
não são proibidas por ANBC0
não são tratadas como bug do instrumento
não devem ser removidas para “limpar” o experimento
```

Se emergirem da dinâmica congelada e produzirem desvios materiais de H-A1S,
constituem exatamente o tipo de alternativa que A1a deve conseguir detectar.

## 10.1.5. Papel limitado de ANBC0

ANBC0 não escolhe entre H-A1S e `M_alt`.

Ele verifica apenas se a implementação tornou H-A1S inevitável antes da observação:

```text
H-A1S inevitável por construção
    -> FAIL_DERIVATIONAL
    -> A1a não é teste independente

H-A1S não inevitável por construção
    -> PASS_DISCRIMINATIVE
    -> A1a pode confrontar H-A1S com M_alt

estatuto não resolvido
    -> INCONCLUSIVE_ANALYTIC
```

Uma dependência emergente de resistência em relação ao recurso, por exemplo
`h(A)` ou `phi(A,iota_obs)`, não é automaticamente falha de ANBC0.
Ela pertence a `M_alt`, salvo se tiver sido implementada de modo a tornar
matematicamente inevitável a própria relação específica de H-A1S.

## 10.1.6. Cadeia conceitual congelada

```text
TEORIA-BASE
  eta0 = omega / (1 + iota_obs + kappa*EH)

EXTENSÃO PROSPECTIVA H-A1S
  eta(A,p) = A * eta0(p)

HIPÓTESES RIVAIS M_alt
  atenção como resistência aditiva
  interação A × iota_obs
  outras formas não separáveis

A1a
  confrontar H-A1S com M_alt sem hard-code da forma H-A1S
```

# 11. Papel de EH em A1a

`EH` não redefine atenção.

Os estratos de estado existem apenas no CANAL_ETA para comparar condições em regimes de estado prospectivamente definidos.

A teoria **não** exige:

```text
A_i(EH_LOW) = A_i(EH_MID) = A_i(EH_HIGH)
```

e a v2.0.0 não cria nenhuma dessas variáveis.

A previsão correta é relativa:

\[
\frac{\eta(A_2,EH)}
{\eta(A_1,EH)}
=
\frac{A_2}{A_1}
\]

em cada regime de estado no qual `eta_hat` seja identificável.

Se um estrato não contiver informação dinâmica suficiente, isso é problema de identificação de `eta_hat` e pertence a `AETA0`; não gera um Gate novo sobre atenção.

---

# 12. Estimando primário de A1a

Para cada observador `i`, estrato de estado `s` e par de braços prospectivamente definido `a,b`, formar somente depois dos dois canais:

\[
q_{i,s,a}=
\frac{\widehat\eta_{i,s,a}}
{A_{i,a}}
\]

e o contraste estatístico:

\[
\boxed{
C_{i,s}^{a,b}
=
\log q_{i,s,a}
-
\log q_{i,s,b}
}
\]

Este contraste **não é nova variável teórica**. É apenas operacionalização estatística da predição canônica `eta/A = invariável entre braços`.

Sob separabilidade:

\[
C_{i,s}^{a,b}\approx0.
\]

A lista de pares de braços e estratos primários deve ser fechada antes da coleta.

---

# 13. ASEP0 — decisão primária de A1a

A definição exige distinguir prospectivamente:

```text
M_sep = H-A1S: atenção multiplicativa separável
M_alt = resistência aditiva dependente de atenção, interação A×iota_obs,
        ou outra forma não separável prospectivamente admissível
```

A v2.0.0 fixa a forma da decisão, mas **não escolhe ainda a margem numérica**.

Parâmetros a congelar na versão run-ready:

```text
Delta_sep
alpha_family
método de controle da família de contrastes
procedimento de intervalo
lista fechada de contrastes primários
```

Regras finais obrigatórias:

### Compatível

Todos os contrastes primários identificáveis devem satisfazer o critério de equivalência congelado, com todos os Gates pré-requisitos em PASS:

```text
ATTENTION_MULTIPLICATIVE_SEPARABILITY_COMPATIBLE [C1]
```

### Refutado

Violação material prospectivamente definida em pelo menos um contraste primário, com identificação/potência/Gates adequados:

```text
ATTENTION_MULTIPLICATIVE_SEPARABILITY_REFUTED [C1]
```

### Inconclusivo

Falha de benchmark, manipulação, isolamento, identificação, competência, integridade ou potência:

```text
INCONCLUSIVE_*
```

Nunca converter insuficiência de dados em refutação.

---

# 14. ANBC0 — estatuto discriminativo do teste

ANBC0 não é hipótese sobre a HUMH e **não exige que `eta/A` possa variar**.

Ele pergunta somente:

> dadas a microdinâmica basal e a operacionalização experimental congeladas,
> H-A1S poderia ser contrariada pelo simulador ou é uma consequência matemática
> inevitável da própria construção?

Classificações:

```text
PASS_DISCRIMINATIVE
FAIL_DERIVATIONAL
INCONCLUSIVE_ANALYTIC
```

`PASS_DISCRIMINATIVE`: H-A1S não é implicada necessariamente.

`FAIL_DERIVATIONAL`: H-A1S decorre necessariamente das regras implementadas.
Isso não refuta H-A1S nem a HUMH. Apenas impede interpretar A1a como teste
computacional independente:

```text
A1a = MECHANISM_DEMONSTRATION_ONLY [C1]
ASEP0_CONFIRMATORY = NOT_AUTHORIZED
```

`INCONCLUSIVE_ANALYTIC`: ainda não foi possível determinar o estatuto.

ANBC0 não deve eliminar alternativas científicas para tornar o desenho “mais limpo”.
Em particular, uma forma emergente `iota_obs(A)` ou `h(A)` pertence a `M_alt` e
deve permanecer detectável por A1a. Ela só entra no escopo de ANBC0 se a forma
implementada tornar matematicamente inevitável a própria relação específica de H-A1S.

É proibido escolher ou trocar a microdinâmica apenas para obter
`PASS_DISCRIMINATIVE`.

O padrão `y=S*G`, quando suas premissas matemáticas forem satisfeitas, continua
sendo apenas um diagnóstico suficiente de caso derivacional. Ele não significa
que a teoria exija variabilidade de `eta/A`.

Status atual:

```text
ATTENTION_INSTRUMENT = FROZEN_LOGICAL_WORK_BUDGET
A1A_OBSERVER_MICRODYNAMIC = UNRESOLVED_CANONICAL_OR_AUXILIARY_MAPPING
ANBC0 = NOT_READY_FOR_CLASSIFICATION
```

---
# 15. ACOMP0 — competência adversarial

Antes do run científico, o pipeline deve demonstrar em harness sintético que detecta:

1. uma condição separável conhecida;
2. pelo menos uma violação não separável conhecida;
3. a direção correta do contraste;
4. a competência mínima prospectivamente congelada.

O harness adversarial não pode compartilhar a regra geradora do outcome real.

Se a competência mínima não for atingida:

```text
ACOMP0 = FAIL
ASEP0 = INCONCLUSIVE_PIPELINE_COMPETENCE
```

---

# 16. A1b — ATTENTION DISTRIBUTION EFFECT

A1b usa exclusivamente as variáveis teóricas:

\[
\bar A
\quad\text{e}\quad
D_A.
\]

Pergunta científica:

> mantendo \(\bar A\) constante dentro da margem prospectiva, alterar \(D_A\) modifica a dinâmica coletiva?

Desenho conceitual:

```text
UNIFORM:
  A_i aproximadamente semelhante entre observadores
  D_A menor

HETEROGENEOUS:
  distribuição de A_i mais dispersa
  D_A maior
```

Restrições:

- `D_i` deve ser idêntico por observador entre braços pareados;
- somente a capacidade de atender a demanda é redistribuída;
- nenhuma realocação pode responder a `EH`, crença, dívida, sucesso ou falha durante a trajetória;
- regra de alocação exógena e congelada;
- `A_bar` não pode ser “corrigido” depois olhando o outcome coletivo.

A1b não é consequência automática de H-A1S e possui inferência própria em `ADIST0`.

---

# 17. Outcome primário de A1b

A definição canônica não congela nesta etapa qual métrica coletiva específica deve ser o outcome primário de A1b.

Portanto, a v2.0.0 **não inventa uma**.

Antes de autorizar run, a versão run-ready deverá escolher uma métrica já definida na linhagem teórica, declarar sua seção/origem normativa e congelar:

```text
outcome coletivo primário
margem de igualdade de A_bar
diferença mínima de D_A
margem de efeito/materialidade
regra de decisão
tamanho amostral
```

Sem essa escolha rastreável:

```text
ADIST0 = NOT_AUTHORIZED
```

A restrição temporal é explícita:

```text
A1B_PRIMARY_OUTCOME_MUST_BE_FROZEN_BEFORE_FIRST_SCIENTIFIC_TRAJECTORY_IS_GENERATED
```

A escolha específica deve ocorrer **antes do início da coleta científica**, nunca depois de observar A1a ou qualquer outro outcome do mesmo conjunto de trajetórias. O outcome de A1b deve ser uma métrica já pertencente à linhagem teórica e portar `canonical_refs` qualificados.

A1a pode ser preparado independentemente; A1b não pode ser improvisado durante ou após o run.

---

# 18. Gates — lista fechada

A lista de Gates científicos/integridade da v2.0.0 é **exatamente** a estrutura mínima da definição:

```text
AGOV0   — governança/hashes/KREF0/traceability
AMEAS0  — contrato D/U/W/L_A e contadores
ABENCH0 — benchmark cego de instrumentação/deadline
AMAN0   — manipulation check de A
AISO0   — isolamento estrutural
AETA0   — identificação independente de eta_hat
ANBC0   — separabilidade não garantida por construção
ACOMP0  — competência para detectar não-separabilidade
ASEP0   — teste primário H-A1S
ADIST0  — teste A1b, se autorizado
AINT0   — integridade/RNG/checkpoint/reprodutibilidade
```

Não existem Gates científicos adicionais nesta versão.

---

# 19. Subchecks permitidos — sem criar nova teoria

Verificações úteis da série v1.0.x podem ser preservadas somente como subchecks:

```text
AGOV0
  .REFERENT_HASHES
  .NO_ATTENTION_IN_OBSERVER_RULE
  .TRACEABILITY_MANIFEST_COMPLETE

AMEAS0
  .NO_DOUBLE_COUNTING
  .D_IDENTITY_PAIRED_ARMS
  .DEADLINE_ACCOUNTING
  .RIGHT_EDGE_ACCOUNTING

AETA0
  .ETA_FINITE_AND_IDENTIFIABLE
  .TRAJECTORY_ONLY_DEPENDENCY_AUDIT
  .PERMUTATION_INVARIANCE_TO_A_COUNTERS
  .SYNTHETIC_SLOPE_RECOVERY
  .QUEUE_END_TO_END_RECOVERY

ANBC0
  .ANALYTIC_NONCONSTRUCTION
  .STATIONARY_WITNESS

AISO0
  .SERVICE_INVARIANCE
  .PROPAGATION_INVARIANCE
  .TOPOLOGY_INVARIANCE
  .EXOGENOUS_DEMAND_INVARIANCE

AINT0
  .CRN_IDENTITY
  .RNG_LABEL_AUDIT
  .CHECKPOINT_RESUME_EQUIVALENCE
  .NO_RIGHT_CENSORING
  .DEMAND_CHECKSUMS
```

Esses nomes não podem ser usados para acrescentar condição científica não contida no Gate pai.

Itens explicitamente removidos como Gates:

```text
AEXP0
ACSUP0
ASTRAT0
AETA1
AETA2
ANBC1
ACRN0
ACRNB0
ACKPT0
ARULE0
```

Quando úteis, suas verificações técnicas são absorvidas pelos Gates canônicos acima.

---

# 20. AMAN0 — manipulation check

AMAN0 verifica apenas que os instrumentos `P_i_obs` geraram níveis de `A_i` suficientemente distintos segundo regra congelada.

Isso não conta como evidência de H-A1S.

Parâmetros ainda a congelar:

```text
número de braços
alvos/faixas instrumentais de A
contraste mínimo entre braços
regra para saturação em 0/1
```

É proibido escolher ou reajustar esses valores usando `eta_hat`, `EH` ou outcome coletivo.

---

# 21. AISO0 — isolamento

Entre braços pareados, manter invariantes, dentro de tolerâncias técnicas pré-fixadas:

```text
CPU global
manutenção
serviço
propagação
R_eff*
topologia
microdinâmica estrutural
D_i
conteúdo observacional
RNG exógeno
```

Somente `P_i_obs` varia.

Falha:

```text
INCONCLUSIVE_TECHNICAL_OR_ISOLATION
```

---

# 22. AETA0 — identificação de eta_hat

AETA0 exige cumulativamente:

1. informação dinâmica suficiente;
2. `eta_hat` finito nos estratos primários requeridos;
3. módulo ETA sem dependência de contadores/arm/budget;
4. permutar `U/D/A` mantendo trajetória fixa não altera `eta_hat`;
5. trajetória sintética de inclinação conhecida é recuperada corretamente.

Os seguintes parâmetros devem ser congelados antes do run:

```text
delta_drive
min_steps
min_sum_x2
estratos de estado
regra de passos elegíveis
```

Insuficiência em qualquer estrato primário produz categoria inconclusiva de identificação; não cria hipótese sobre `A_i`.


## 22.1. Harness técnico AETA0 — especificado, não executado

Antes de qualquer trajetória científica, o módulo `CANAL_ETA` deve passar três testes independentes de A1a:

```text
SYNTHETIC_SLOPE_RECOVERY
PERMUTATION_INVARIANCE_TO_A_COUNTERS
TRAJECTORY_SENSITIVITY
```

No primeiro, usar trajetória sintética de forma:

\[
y_t=\beta x_t+\epsilon_t
\]

com `beta` conhecido somente pelo harness. Os números do harness são `IMPLEMENTATION_ONLY` e não podem ser reutilizados para margem, poder, braços ou outcome científico.

No segundo, manter `p(t)` e `p_alvo(t)` bitwise fixos e permutar/substituir `U,D,A,arm,budget`; `eta_hat` deve permanecer bitwise idêntico.

No terceiro, manter os contadores fixos e alterar somente a trajetória sintética; `eta_hat` deve responder à inclinação imposta.

Status nesta v2.0.0:

```text
AETA0_HARNESS = SPECIFIED_NOT_EXECUTED
```

---

# 23. AINT0 — integridade

AINT0 cobre:

- seeds novas para a coleta v2;
- CRN nas condições pareadas;
- identidade de demanda;
- checksums;
- reprodutibilidade;
- checkpoint/resume sem alteração de resultado;
- ausência de top-up pós-outcome;
- ausência de censura direita não prevista;
- registro da versão exata da spec e implementação.

---

# 24. Novas seeds obrigatórias

Todo run científico v2 deve usar seeds nunca utilizadas na série v1.0.x.

As seeds confirmatórias não podem ser abertas em piloto.

Benchmarks técnicos e adversariais usam namespaces RNG separados da coleta científica.

---

# 25. Unidade inferencial

A unidade inferencial final ainda precisa ser congelada na versão run-ready, coerente com o pareamento por replicação/observador e sem pseudo-replicação.

A escolha deve ser feita antes de nova coleta e documentada como operacionalização estatística, não como variável teórica.

---

# 26. Itens numéricos ainda NÃO congelados

A v2.0.0 conscientemente deixa os seguintes campos como `UNFROZEN_REQUIRED_BEFORE_RUN`:

```text
N
W
L_grid
budgets instrumentais de ABENCH0
critérios instrumentais de ABENCH0
L_A
número e níveis dos braços A1a
delta_drive
min_steps
min_sum_x2
estratos de estado do CANAL_ETA
lista de contrastes primários
Delta_sep
alpha_family
método de multiplicidade
procedimento de CI
competência mínima de ACOMP0
tamanho amostral/poder
outcome coletivo primário A1b
margem de matching de A_bar
diferença mínima de D_A
margem de efeito A1b
```

Nenhum desses campos pode ser preenchido com base em outcomes científicos da série v1.0.x.

Além desses campos numéricos, existe um bloqueio não numérico:

```text
observer_microdynamic_contract
```

Ele deve ser resolvido **antes** do congelamento run-ready e portar `canonical_refs` próprios.

O contrato já congelado de `p_alvo` ainda exige prospectivamente:

```text
p_A
p_B
number_of_target_episodes
A_B_episode_balance_and_order
target_episode_length
initial_p_rule
target_stationarity_certification
```


---

# 27. Procedimento autorizado para congelar os números

A próxima versão run-ready só pode ser preparada nesta ordem:

1. identificar uma microdinâmica do observador com `canonical_refs` qualificadas;
2. congelar seu contrato funcional sem usar outcomes v1.0.x;
3. classificar `ANBC0` analiticamente como discriminativo, derivacional ou inconclusivo;
4. não alterar a microdinâmica para obter uma classe desejada de `ANBC0`; depois congelar os parâmetros numéricos restantes;
5. executar/validar o harness técnico `AETA0`, sem outcomes científicos;
6. executar `ABENCH0` cego de instrumentação/deadline;
7. congelar níveis instrumentais de atenção, estratos, contrastes e critérios de identificação;
8. validar `ACOMP0`;
9. definir tamanho amostral/poder por efeitos sintéticos prospectivos ou precisão-alvo, nunca por efeitos v1.0.x;
10. usar literatura/critério teórico externo somente se explicitamente declarado e congelado antes da coleta.

Somente após a resolução da microdinâmica, elegibilidade de `ANBC0` e congelamento restante, gerar:

```text
HUMH_A0_A1_SPEC_2.0.1_RUN_READY
```

com SHA-256 próprio.

---

# 28. Regra automática de rastreabilidade para o código

A futura implementação deve carregar um manifest embutido contendo, para cada entidade:

```text
id
kind
status
canonical_refs:
  - artifact_id
    sha256
    section
    clause_or_statement
scientific_role
inputs
outputs
parent_gate
```

O manifesto deve manter também um registro fechado dos artefatos canônicos e seus hashes.

Build/run científico deve falhar se:

```text
scientific_role != IMPLEMENTATION_ONLY
AND canonical_refs estiver vazio
```

ou se qualquer `canonical_ref.sha256` divergir do hash registrado para o respectivo `artifact_id`, ou se existir Gate raiz não pertencente à lista fechada do §18.

A unidade de rastreabilidade, portanto, não é “seção N” isoladamente, mas:

```text
entidade científica
→ artifact_id
→ SHA-256
→ seção/cláusula
→ operacionalização
```


---


## 28.1. Fechamento do manifesto de rastreabilidade

O manifesto `HUMH_A0_A1_Traceabilidade_v2.0.0.json` representa mecanicamente,
além das variáveis, hipóteses e Gates:

```text
M_alt
    hipótese rival formal de H-A1S

ANBC0.NC1_DERIVATIONAL_PATTERN
    subcheck derivacional de ANBC0

result_logic
    mapeamento verificável entre condições/Gates e disposição final

scientific_sequence
    A0 -> A1a -> A1b; A2 não autorizado
```

O padrão histórico em que um identificador, como `ACSUP0`, aparece simultaneamente
em `retired_as_root_gates` e `forbidden_scientific_entities` é permitido pelo
validador: significa apenas que o Gate foi aposentado e também não pode reaparecer
como entidade científica.

Esses objetos são de governança e rastreabilidade. Eles não alteram H-A1S,
`M_alt`, os estimandos, os Gates ou qualquer critério científico.

# 29. Critérios de conclusão

## A0

Pode concluir somente:

```text
ATTENTION_MEASUREMENT_CONTRACT_VALID
ATTENTION_MEASUREMENT_CONTRACT_INVALID
```

Sem status de suporte teórico.

## A1a

Com todos os pré-requisitos adequados:

```text
ATTENTION_MULTIPLICATIVE_SEPARABILITY_COMPATIBLE [C1]
ATTENTION_MULTIPLICATIVE_SEPARABILITY_REFUTED [C1]
INCONCLUSIVE_*
```

## A1b

Somente depois de ADIST0 ser totalmente congelado:

```text
ATTENTION_DISTRIBUTION_EFFECT_ESTABLISHED/COMPATIBLE [C1]
ATTENTION_DISTRIBUTION_EFFECT_NOT_ESTABLISHED
ATTENTION_DISTRIBUTION_EFFECT_REFUTED
INCONCLUSIVE_*
```

## A2

```text
NOT AUTHORIZED / NOT TESTED
```

---

# 30. Regra final

A v2.0.0 não tenta salvar, ajustar ou reinterpretar a série v1.0.x.

Ela restabelece a relação:

\[
\boxed{
\text{definição canônica}
\rightarrow
\text{variável/hipótese}
\rightarrow
\text{operacionalização}
\rightarrow
\text{Gate}
\rightarrow
\text{código}
\rightarrow
\text{resultado}
}
\]

e proíbe a direção inversa:

\[
\boxed{
\text{resultado observado}
\not\rightarrow
\text{nova variável/Gate/hipótese ad hoc}.
}
\]

**Estado final desta versão:**

```text
TRACEABILITY_RESET = FROZEN
SCIENTIFIC_MODEL = CANONICAL_A0_A1_ONLY
SCIENTIFIC_RUN_NOT_AUTHORIZED
NEXT = FREEZE_NUMERICAL_DESIGN_WITHOUT_V1_SCIENTIFIC_OUTCOMES
```
