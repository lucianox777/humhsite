# HUMH A0/A1 v2.0.0 — publicação autocontida mínima

Este pacote contém o fechamento mínimo autocontido necessário para publicar e auditar
a especificação pré-código A0/A1 v2.0.0.

## Status

`scientific_run_authorized = false`

Este pacote publica o desenho e sua rastreabilidade. Não contém resultados científicos.

## Árvore

```text
HUMH_A0_A1_v2.0.0_Publicacao_Autocontida/
├── README.md
├── TREE.txt
├── 01_experimento/
│   ├── HUMH_A0_A1_Especificacao_Experimental_v2.0.0.md
│   └── HUMH_A0_A1_Traceabilidade_v2.0.0.json
├── 02_dependencias/
│   ├── HUMH_Definicao_Atencao_Observacional_Efetiva_v1.0.0.md
│   ├── teoria.md
│   └── DEPENDENCIES.lock.json
└── 03_integridade/
    ├── SHA256SUMS.txt
    └── verify.py
```

## Artefatos normativos próprios do experimento

- `01_experimento/HUMH_A0_A1_Especificacao_Experimental_v2.0.0.md`
- `01_experimento/HUMH_A0_A1_Traceabilidade_v2.0.0.json`

## Dependências canônicas ativas incorporadas

- `02_dependencias/HUMH_Definicao_Atencao_Observacional_Efetiva_v1.0.0.md`
  - SHA-256: `3f89058c0931515abe94f56393733cdebed8f49a35003ae1b17949686540bb7a`
- `02_dependencias/teoria.md`
  - SHA-256: `3ce6c097a11c7c33cc94439e44d2ec2821b60affbfedec8401cc9572d58bf23b`

Os dois arquivos foram incorporados byte a byte e seus hashes correspondem aos locks
canônicos usados pela v2.0.0.

## Linhagem não incluída fisicamente

Núcleo, Programa N3 e KREF0 permanecem registrados em `DEPENDENCIES.lock.json` apenas
como proveniência. Eles não são dependências ativas dos `canonical_refs` do fechamento
atual e, por isso, não integram a árvore mínima autocontida.

## Verificação

Execute:

```text
python 03_integridade/verify.py
```

O verificador confirma:
- integridade de todos os arquivos materializados;
- presença das duas dependências ativas;
- correspondência exata dos SHAs canônicos definidos no lock.
